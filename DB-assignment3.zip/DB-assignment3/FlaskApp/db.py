from sqlalchemy import create_engine

DATABASE_URL = "postgresql+psycopg2://postgres:1@localhost:5432/caregiver_platform"

engine = create_engine(DATABASE_URL)