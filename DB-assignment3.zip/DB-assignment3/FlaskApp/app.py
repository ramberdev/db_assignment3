from flask import Flask, redirect, url_for
from routes.users import init_user_routes
from routes.caregivers import init_caregiver_routes
from routes.members import init_member_routes
from routes.addresses import init_address_routes
from routes.jobs import init_job_routes
from routes.job_applications import init_job_application_routes
from routes.appointments import init_appointment_routes

app = Flask(__name__)


@app.route("/")
def home_redirect():
    return redirect(url_for("list_users"))

init_user_routes(app)
init_caregiver_routes(app)
init_member_routes(app)
init_address_routes(app)
init_job_routes(app)
init_job_application_routes(app)
init_appointment_routes(app)

if __name__ == "__main__":
    app.run(debug=True)