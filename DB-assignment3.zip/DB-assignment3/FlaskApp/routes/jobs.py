from flask import render_template, request, redirect, url_for
from sqlalchemy import text
from db import engine


def init_job_routes(app):

    @app.route("/jobs")
    def list_jobs():
        with engine.connect() as conn:
            result = conn.execute(text("""
                SELECT j.*, u.given_name, u.surname
                FROM job j
                JOIN member m ON j.member_user_id = m.member_user_id
                JOIN "user" u ON m.member_user_id = u.user_id
                ORDER BY j.job_id
            """))
            jobs = result.fetchall()
        return render_template("jobs_list.html", jobs=jobs)

    @app.route("/jobs/create", methods=["GET", "POST"])
    def create_job():
        if request.method == "POST":
            member_user_id = request.form["member_user_id"]
            required_caregiving_type = request.form["required_caregiving_type"]
            other_requirements = request.form["other_requirements"] or None
            date_posted = request.form["date_posted"]  # yyyy-mm-dd

            with engine.begin() as conn:
                conn.execute(
                    text("""
                        INSERT INTO job (member_user_id, required_caregiving_type, other_requirements, date_posted)
                        VALUES (:mid, :ctype, :req, :datep)
                    """),
                    {
                        "mid": member_user_id,
                        "ctype": required_caregiving_type,
                        "req": other_requirements,
                        "datep": date_posted,
                    },
                )
            return redirect(url_for("list_jobs"))

        with engine.connect() as conn:
            result = conn.execute(text("""
                SELECT m.member_user_id, u.given_name, u.surname
                FROM member m
                JOIN "user" u ON m.member_user_id = u.user_id
                ORDER BY m.member_user_id
            """))
            members = result.fetchall()

        return render_template("job_form.html", job=None, members=members)

    @app.route("/jobs/<int:jid>/edit", methods=["GET", "POST"])
    def edit_job(jid):
        if request.method == "POST":
            required_caregiving_type = request.form["required_caregiving_type"]
            other_requirements = request.form["other_requirements"] or None
            date_posted = request.form["date_posted"]

            with engine.begin() as conn:
                conn.execute(
                    text("""
                        UPDATE job
                        SET required_caregiving_type = :ctype,
                            other_requirements = :req,
                            date_posted = :datep
                        WHERE job_id = :jid
                    """),
                    {
                        "jid": jid,
                        "ctype": required_caregiving_type,
                        "req": other_requirements,
                        "datep": date_posted,
                    },
                )
            return redirect(url_for("list_jobs"))

        with engine.connect() as conn:
            result = conn.execute(
                text("""
                    SELECT j.*, u.given_name, u.surname
                    FROM job j
                    JOIN member m ON j.member_user_id = m.member_user_id
                    JOIN "user" u ON m.member_user_id = u.user_id
                    WHERE j.job_id = :jid
                """),
                {"jid": jid},
            )
            job = result.fetchone()

        if job is None:
            return "Job not found", 404

        return render_template("job_form.html", job=job, members=None)

    @app.route("/jobs/<int:jid>/delete", methods=["POST"])
    def delete_job(jid):
        with engine.begin() as conn:
            conn.execute(
                text("DELETE FROM job WHERE job_id = :jid"),
                {"jid": jid},
            )
        return redirect(url_for("list_jobs"))