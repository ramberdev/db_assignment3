from flask import render_template, request, redirect, url_for
from sqlalchemy import text
from db import engine


def init_user_routes(app):

    @app.route("/users")
    def list_users():
        with engine.connect() as conn:
            result = conn.execute(text('SELECT * FROM "user" ORDER BY user_id'))
            users = result.fetchall()
        return render_template("users_list.html", users=users)

    @app.route("/users/create", methods=["GET", "POST"])
    def create_user():
        if request.method == "POST":
            email = request.form["email"]
            given_name = request.form["given_name"]
            surname = request.form["surname"]
            city = request.form["city"] or None
            phone_number = request.form["phone_number"]
            profile_description = request.form["profile_description"] or None
            password = request.form["password"]

            with engine.begin() as conn:
                conn.execute(
                    text("""
                        INSERT INTO "user" 
                        (email, given_name, surname, city, phone_number, profile_description, password)
                        VALUES (:email, :given_name, :surname, :city, :phone_number, :profile_description, :password)
                    """),
                    {
                        "email": email,
                        "given_name": given_name,
                        "surname": surname,
                        "city": city,
                        "phone_number": phone_number,
                        "profile_description": profile_description,
                        "password": password,
                    },
                )
            return redirect(url_for("list_users"))

        return render_template("user_form.html", user=None)

    @app.route("/users/<int:user_id>/edit", methods=["GET", "POST"])
    def edit_user(user_id):
        if request.method == "POST":
            email = request.form["email"]
            given_name = request.form["given_name"]
            surname = request.form["surname"]
            city = request.form["city"] or None
            phone_number = request.form["phone_number"]
            profile_description = request.form["profile_description"] or None
            password = request.form["password"]

            with engine.begin() as conn:
                conn.execute(
                    text("""
                        UPDATE "user"
                        SET email = :email,
                            given_name = :given_name,
                            surname = :surname,
                            city = :city,
                            phone_number = :phone_number,
                            profile_description = :profile_description,
                            password = :password
                        WHERE user_id = :user_id
                    """),
                    {
                        "email": email,
                        "given_name": given_name,
                        "surname": surname,
                        "city": city,
                        "phone_number": phone_number,
                        "profile_description": profile_description,
                        "password": password,
                        "user_id": user_id,
                    },
                )
            return redirect(url_for("list_users"))

        with engine.connect() as conn:
            result = conn.execute(
                text('SELECT * FROM "user" WHERE user_id = :user_id'),
                {"user_id": user_id},
            )
            user = result.fetchone()

        if user is None:
            return "User not found", 404

        return render_template("user_form.html", user=user)

    @app.route("/users/<int:user_id>/delete", methods=["POST"])
    def delete_user(user_id):
        with engine.begin() as conn:
            conn.execute(
                text('DELETE FROM "user" WHERE user_id = :user_id'),
                {"user_id": user_id},
            )
        return redirect(url_for("list_users"))