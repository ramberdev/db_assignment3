from flask import render_template, request, redirect, url_for
from sqlalchemy import text
from db import engine


def init_caregiver_routes(app):

    @app.route("/caregivers")
    def list_caregivers():
        with engine.connect() as conn:
            result = conn.execute(text("""
                SELECT c.*, u.given_name, u.surname
                FROM caregiver c
                JOIN "user" u ON c.caregiver_user_id = u.user_id
                ORDER BY c.caregiver_user_id
            """))
            caregivers = result.fetchall()
        return render_template("caregivers_list.html", caregivers=caregivers)

    @app.route("/caregivers/create", methods=["GET", "POST"])
    def create_caregiver():
        if request.method == "POST":
            caregiver_user_id = request.form["caregiver_user_id"]
            photo = request.form["photo"] or None
            gender = request.form["gender"]
            caregiving_type = request.form["caregiving_type"]
            hourly_rate = request.form["hourly_rate"]

            with engine.begin() as conn:
                conn.execute(
                    text("""
                        INSERT INTO caregiver (caregiver_user_id, photo, gender, caregiving_type, hourly_rate)
                        VALUES (:id, :photo, :gender, :ctype, :rate)
                    """),
                    {
                        "id": caregiver_user_id,
                        "photo": photo,
                        "gender": gender,
                        "ctype": caregiving_type,
                        "rate": hourly_rate,
                    },
                )
            return redirect(url_for("list_caregivers"))

        with engine.connect() as conn:
            result = conn.execute(text("""
                SELECT user_id, given_name, surname
                FROM "user"
                WHERE user_id NOT IN (SELECT caregiver_user_id FROM caregiver)
                ORDER BY user_id
            """))
            available_users = result.fetchall()

        return render_template("caregiver_form.html", caregiver=None, users=available_users)

    @app.route("/caregivers/<int:cid>/edit", methods=["GET", "POST"])
    def edit_caregiver(cid):
        if request.method == "POST":
            photo = request.form["photo"] or None
            gender = request.form["gender"]
            caregiving_type = request.form["caregiving_type"]
            hourly_rate = request.form["hourly_rate"]

            with engine.begin() as conn:
                conn.execute(
                    text("""
                        UPDATE caregiver
                        SET photo = :photo,
                            gender = :gender,
                            caregiving_type = :ctype,
                            hourly_rate = :rate
                        WHERE caregiver_user_id = :cid
                    """),
                    {
                        "cid": cid,
                        "photo": photo,
                        "gender": gender,
                        "ctype": caregiving_type,
                        "rate": hourly_rate,
                    },
                )
            return redirect(url_for("list_caregivers"))

        with engine.connect() as conn:
            result = conn.execute(
                text("""
                    SELECT c.*, u.given_name, u.surname
                    FROM caregiver c
                    JOIN "user" u ON c.caregiver_user_id = u.user_id
                    WHERE caregiver_user_id = :cid
                """),
                {"cid": cid},
            )
            caregiver = result.fetchone()

        if caregiver is None:
            return "Caregiver not found", 404

        return render_template("caregiver_form.html", caregiver=caregiver, users=None)

    @app.route("/caregivers/<int:cid>/delete", methods=["POST"])
    def delete_caregiver(cid):
        with engine.begin() as conn:
            conn.execute(
                text("DELETE FROM caregiver WHERE caregiver_user_id = :cid"),
                {"cid": cid},
            )
        return redirect(url_for("list_caregivers"))