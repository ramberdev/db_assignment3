from flask import render_template, request, redirect, url_for
from sqlalchemy import text
from db import engine


def init_job_application_routes(app):

    @app.route("/job_applications")
    def list_job_applications():
        with engine.connect() as conn:
            result = conn.execute(text("""
                SELECT ja.*, u.given_name, u.surname, j.job_id
                FROM job_application ja
                JOIN caregiver c ON ja.caregiver_user_id = c.caregiver_user_id
                JOIN "user" u ON c.caregiver_user_id = u.user_id
                JOIN job j ON ja.job_id = j.job_id
                ORDER BY j.job_id, ja.caregiver_user_id
            """))
            job_apps = result.fetchall()
        return render_template("job_applications_list.html", job_apps=job_apps)

    @app.route("/job_applications/create", methods=["GET", "POST"])
    def create_job_application():
        if request.method == "POST":
            caregiver_user_id = request.form["caregiver_user_id"]
            job_id = request.form["job_id"]
            date_applied = request.form["date_applied"]

            with engine.begin() as conn:
                conn.execute(
                    text("""
                        INSERT INTO job_application (caregiver_user_id, job_id, date_applied)
                        VALUES (:cid, :jid, :datea)
                    """),
                    {
                        "cid": caregiver_user_id,
                        "jid": job_id,
                        "datea": date_applied,
                    },
                )
            return redirect(url_for("list_job_applications"))

        with engine.connect() as conn:
            caregivers = conn.execute(text("""
                SELECT c.caregiver_user_id, u.given_name, u.surname
                FROM caregiver c
                JOIN "user" u ON c.caregiver_user_id = u.user_id
                ORDER BY c.caregiver_user_id
            """)).fetchall()

            jobs = conn.execute(text("""
                SELECT j.job_id, u.given_name, u.surname
                FROM job j
                JOIN member m ON j.member_user_id = m.member_user_id
                JOIN "user" u ON m.member_user_id = u.user_id
                ORDER BY j.job_id
            """)).fetchall()

        return render_template("job_application_form.html",
                               job_app=None,
                               caregivers=caregivers,
                               jobs=jobs)

    @app.route("/job_applications/<int:cid>/<int:jid>/edit", methods=["GET", "POST"])
    def edit_job_application(cid, jid):
        if request.method == "POST":
            date_applied = request.form["date_applied"]

            with engine.begin() as conn:
                conn.execute(
                    text("""
                        UPDATE job_application
                        SET date_applied = :datea
                        WHERE caregiver_user_id = :cid AND job_id = :jid
                    """),
                    {"cid": cid, "jid": jid, "datea": date_applied},
                )
            return redirect(url_for("list_job_applications"))

        with engine.connect() as conn:
            job_app = conn.execute(
                text("""
                    SELECT ja.*, u.given_name, u.surname
                    FROM job_application ja
                    JOIN caregiver c ON ja.caregiver_user_id = c.caregiver_user_id
                    JOIN "user" u ON c.caregiver_user_id = u.user_id
                    WHERE ja.caregiver_user_id = :cid AND ja.job_id = :jid
                """),
                {"cid": cid, "jid": jid},
            ).fetchone()

        if job_app is None:
            return "Job application not found", 404

        return render_template("job_application_form.html",
                               job_app=job_app,
                               caregivers=None,
                               jobs=None)

    @app.route("/job_applications/<int:cid>/<int:jid>/delete", methods=["POST"])
    def delete_job_application(cid, jid):
        with engine.begin() as conn:
            conn.execute(
                text("""
                    DELETE FROM job_application
                    WHERE caregiver_user_id = :cid AND job_id = :jid
                """),
                {"cid": cid, "jid": jid},
            )
        return redirect(url_for("list_job_applications"))