from flask import render_template, request, redirect, url_for
from sqlalchemy import text
from db import engine


def init_address_routes(app):

    @app.route("/addresses")
    def list_addresses():
        with engine.connect() as conn:
            result = conn.execute(text("""
                SELECT a.*, u.given_name, u.surname
                FROM address a
                JOIN member m ON a.member_user_id = m.member_user_id
                JOIN "user" u ON m.member_user_id = u.user_id
                ORDER BY a.member_user_id
            """))
            addresses = result.fetchall()
        return render_template("addresses_list.html", addresses=addresses)

    @app.route("/addresses/create", methods=["GET", "POST"])
    def create_address():
        if request.method == "POST":
            member_user_id = request.form["member_user_id"]
            house_number = request.form["house_number"] or None
            street = request.form["street"] or None
            town = request.form["town"]

            with engine.begin() as conn:
                conn.execute(
                    text("""
                        INSERT INTO address (member_user_id, house_number, street, town)
                        VALUES (:mid, :hnum, :street, :town)
                    """),
                    {
                        "mid": member_user_id,
                        "hnum": house_number,
                        "street": street,
                        "town": town,
                    },
                )
            return redirect(url_for("list_addresses"))

        with engine.connect() as conn:
            result = conn.execute(text("""
                SELECT m.member_user_id, u.given_name, u.surname
                FROM member m
                JOIN "user" u ON m.member_user_id = u.user_id
                WHERE m.member_user_id NOT IN (SELECT member_user_id FROM address)
                ORDER BY m.member_user_id
            """))
            members = result.fetchall()

        return render_template("address_form.html", address=None, members=members)

    @app.route("/addresses/<int:mid>/edit", methods=["GET", "POST"])
    def edit_address(mid):
        if request.method == "POST":
            house_number = request.form["house_number"] or None
            street = request.form["street"] or None
            town = request.form["town"]

            with engine.begin() as conn:
                conn.execute(
                    text("""
                        UPDATE address
                        SET house_number = :hnum,
                            street = :street,
                            town = :town
                        WHERE member_user_id = :mid
                    """),
                    {"mid": mid, "hnum": house_number, "street": street, "town": town},
                )
            return redirect(url_for("list_addresses"))

        with engine.connect() as conn:
            result = conn.execute(
                text("""
                    SELECT a.*, u.given_name, u.surname
                    FROM address a
                    JOIN member m ON a.member_user_id = m.member_user_id
                    JOIN "user" u ON m.member_user_id = u.user_id
                    WHERE a.member_user_id = :mid
                """),
                {"mid": mid},
            )
            address = result.fetchone()

        if address is None:
            return "Address not found", 404

        return render_template("address_form.html", address=address, members=None)

    @app.route("/addresses/<int:mid>/delete", methods=["POST"])
    def delete_address(mid):
        with engine.begin() as conn:
            conn.execute(
                text("DELETE FROM address WHERE member_user_id = :mid"),
                {"mid": mid},
            )
        return redirect(url_for("list_addresses"))