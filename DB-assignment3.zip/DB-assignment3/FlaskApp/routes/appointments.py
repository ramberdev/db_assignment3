from flask import render_template, request, redirect, url_for
from sqlalchemy import text
from db import engine


def init_appointment_routes(app):

    @app.route("/appointments")
    def list_appointments():
        with engine.connect() as conn:
            result = conn.execute(text("""
                SELECT a.*, 
                       uc.given_name AS caregiver_name,
                       um.given_name AS member_name
                FROM appointment a
                JOIN caregiver c ON a.caregiver_user_id = c.caregiver_user_id
                JOIN member m ON a.member_user_id = m.member_user_id
                JOIN "user" uc ON c.caregiver_user_id = uc.user_id
                JOIN "user" um ON m.member_user_id = um.user_id
                ORDER BY a.appointment_id
            """))
            appointments = result.fetchall()
        return render_template("appointments_list.html", appointments=appointments)

    @app.route("/appointments/create", methods=["GET", "POST"])
    def create_appointment():
        if request.method == "POST":
            caregiver_user_id = request.form["caregiver_user_id"]
            member_user_id = request.form["member_user_id"]
            appointment_date = request.form["appointment_date"]
            appointment_time = request.form["appointment_time"]
            work_hours = request.form["work_hours"]
            status = request.form["status"]

            with engine.begin() as conn:
                conn.execute(
                    text("""
                        INSERT INTO appointment 
                        (caregiver_user_id, member_user_id, appointment_date, appointment_time, work_hours, status)
                        VALUES (:cid, :mid, :date, :time, :hours, :status)
                    """),
                    {
                        "cid": caregiver_user_id,
                        "mid": member_user_id,
                        "date": appointment_date,
                        "time": appointment_time,
                        "hours": work_hours,
                        "status": status,
                    },
                )
            return redirect(url_for("list_appointments"))

        with engine.connect() as conn:
            caregivers = conn.execute(text("""
                SELECT c.caregiver_user_id, u.given_name, u.surname
                FROM caregiver c
                JOIN "user" u ON c.caregiver_user_id = u.user_id
                ORDER BY c.caregiver_user_id
            """)).fetchall()

            members = conn.execute(text("""
                SELECT m.member_user_id, u.given_name, u.surname
                FROM member m
                JOIN "user" u ON m.member_user_id = u.user_id
                ORDER BY m.member_user_id
            """)).fetchall()

        return render_template("appointment_form.html",
                               appointment=None,
                               caregivers=caregivers,
                               members=members)

    @app.route("/appointments/<int:aid>/edit", methods=["GET", "POST"])
    def edit_appointment(aid):
        if request.method == "POST":
            appointment_date = request.form["appointment_date"]
            appointment_time = request.form["appointment_time"]
            work_hours = request.form["work_hours"]
            status = request.form["status"]

            with engine.begin() as conn:
                conn.execute(
                    text("""
                        UPDATE appointment
                        SET appointment_date = :date,
                            appointment_time = :time,
                            work_hours = :hours,
                            status = :status
                        WHERE appointment_id = :aid
                    """),
                    {
                        "aid": aid,
                        "date": appointment_date,
                        "time": appointment_time,
                        "hours": work_hours,
                        "status": status,
                    },
                )
            return redirect(url_for("list_appointments"))

        with engine.connect() as conn:
            appointment = conn.execute(
                text("""
                    SELECT a.*, 
                           uc.given_name AS caregiver_name,
                           um.given_name AS member_name
                    FROM appointment a
                    JOIN caregiver c ON a.caregiver_user_id = c.caregiver_user_id
                    JOIN member m ON a.member_user_id = m.member_user_id
                    JOIN "user" uc ON c.caregiver_user_id = uc.user_id
                    JOIN "user" um ON m.member_user_id = um.user_id
                    WHERE a.appointment_id = :aid
                """),
                {"aid": aid},
            ).fetchone()

        if appointment is None:
            return "Appointment not found", 404

        return render_template("appointment_form.html",
                               appointment=appointment,
                               caregivers=None,
                               members=None)

    @app.route("/appointments/<int:aid>/delete", methods=["POST"])
    def delete_appointment(aid):
        with engine.begin() as conn:
            conn.execute(
                text("DELETE FROM appointment WHERE appointment_id = :aid"),
                {"aid": aid},
            )
        return redirect(url_for("list_appointments"))