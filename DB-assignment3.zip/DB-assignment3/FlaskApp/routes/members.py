from flask import render_template, request, redirect, url_for
from sqlalchemy import text
from db import engine


def init_member_routes(app):

    @app.route("/members")
    def list_members():
        with engine.connect() as conn:
            result = conn.execute(text("""
                SELECT m.*, u.given_name, u.surname
                FROM member m
                JOIN "user" u ON m.member_user_id = u.user_id
                ORDER BY m.member_user_id
            """))
            members = result.fetchall()
        return render_template("members_list.html", members=members)

    @app.route("/members/create", methods=["GET", "POST"])
    def create_member():
        if request.method == "POST":
            member_user_id = request.form["member_user_id"]
            house_rules = request.form["house_rules"] or None
            dependent_description = request.form["dependent_description"]

            with engine.begin() as conn:
                conn.execute(
                    text("""
                        INSERT INTO member (member_user_id, house_rules, dependent_description)
                        VALUES (:id, :rules, :desc)
                    """),
                    {
                        "id": member_user_id,
                        "rules": house_rules,
                        "desc": dependent_description,
                    },
                )
            return redirect(url_for("list_members"))

        with engine.connect() as conn:
            result = conn.execute(text("""
                SELECT user_id, given_name, surname
                FROM "user"
                WHERE user_id NOT IN (SELECT member_user_id FROM member)
                ORDER BY user_id
            """))
            available_users = result.fetchall()

        return render_template("member_form.html", member=None, users=available_users)

    @app.route("/members/<int:mid>/edit", methods=["GET", "POST"])
    def edit_member(mid):
        if request.method == "POST":
            house_rules = request.form["house_rules"] or None
            dependent_description = request.form["dependent_description"]

            with engine.begin() as conn:
                conn.execute(
                    text("""
                        UPDATE member
                        SET house_rules = :rules,
                            dependent_description = :desc
                        WHERE member_user_id = :mid
                    """),
                    {"rules": house_rules, "desc": dependent_description, "mid": mid},
                )
            return redirect(url_for("list_members"))

        with engine.connect() as conn:
            result = conn.execute(
                text("""
                    SELECT m.*, u.given_name, u.surname
                    FROM member m
                    JOIN "user" u ON m.member_user_id = u.user_id
                    WHERE m.member_user_id = :mid
                """),
                {"mid": mid},
            )
            member = result.fetchone()

        if member is None:
            return "Member not found", 404

        return render_template("member_form.html", member=member, users=None)

    @app.route("/members/<int:mid>/delete", methods=["POST"])
    def delete_member(mid):
        with engine.begin() as conn:
            conn.execute(
                text("DELETE FROM member WHERE member_user_id = :mid"),
                {"mid": mid},
            )
        return redirect(url_for("list_members"))