CREATE TABLE "user" (
    user_id SERIAL PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    given_name VARCHAR(100) NOT NULL,
    surname VARCHAR(100) NOT NULL,
    city VARCHAR(100),
    phone_number VARCHAR(20) NOT NULL,
    profile_description TEXT,
    password VARCHAR(255) NOT NULL
);

CREATE TABLE caregiver (
    caregiver_user_id INTEGER PRIMARY KEY,
    photo TEXT,
    gender VARCHAR(20) NOT NULL,
    caregiving_type VARCHAR(50) NOT NULL,
    hourly_rate NUMERIC(6,2) NOT NULL,
    CONSTRAINT caregiver_foreignkey
        FOREIGN KEY (caregiver_user_id)
            REFERENCES "user"(user_id)
            ON DELETE CASCADE
);

CREATE TABLE member (
    member_user_id INTEGER PRIMARY KEY,
    house_rules TEXT,
    dependent_description TEXT NOT NULL,
    CONSTRAINT member_foreignkey
        FOREIGN KEY (member_user_id)
            REFERENCES "user"(user_id)
            ON DELETE CASCADE
);

CREATE TABLE address (
    member_user_id INTEGER PRIMARY KEY,
    house_number VARCHAR(20),
    street VARCHAR(255),
    town VARCHAR(100) NOT NULL,
    CONSTRAINT address_foreignkey
        FOREIGN KEY (member_user_id)
            REFERENCES member(member_user_id)
            ON DELETE CASCADE
);

CREATE TABLE job (
    job_id SERIAL PRIMARY KEY,
    member_user_id INTEGER NOT NULL,
    required_caregiving_type VARCHAR(50) NOT NULL,
    other_requirements TEXT,
    date_posted DATE NOT NULL,
    CONSTRAINT job_foreignkey
        FOREIGN KEY (member_user_id)
            REFERENCES member(member_user_id)
            ON DELETE CASCADE
);

CREATE TABLE job_application (
    caregiver_user_id INTEGER NOT NULL,
    job_id INTEGER NOT NULL,
    date_applied DATE NOT NULL,
    PRIMARY KEY (caregiver_user_id, job_id),
    CONSTRAINT application_caregiver_foreignkey
        FOREIGN KEY (caregiver_user_id)
            REFERENCES caregiver(caregiver_user_id)
            ON DELETE CASCADE,
    CONSTRAINT application_job_foreignkey
        FOREIGN KEY (job_id)
            REFERENCES job(job_id)
            ON DELETE CASCADE
);

CREATE TABLE appointment (
    appointment_id SERIAL PRIMARY KEY,
    caregiver_user_id INTEGER NOT NULL,
    member_user_id INTEGER NOT NULL,
    appointment_date DATE NOT NULL,
    appointment_time TIME NOT NULL,
    work_hours NUMERIC(3,1) NOT NULL,
    status VARCHAR(20) NOT NULL,
    CONSTRAINT appointment_caregiver_foreignkey
        FOREIGN KEY (caregiver_user_id)
            REFERENCES caregiver(caregiver_user_id)
            ON DELETE CASCADE,
    CONSTRAINT appointment_member_foreignkey
    FOREIGN KEY (member_user_id)
        REFERENCES member(member_user_id)
        ON DELETE CASCADE
);