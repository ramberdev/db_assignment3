from sqlalchemy import create_engine, text

# Connecting the DB
engine = create_engine("postgresql+psycopg2://postgres:1@localhost:5432/caregiver_platform")

# Helper function for SQL queries without output
def exec_sql(sql: str):
    with engine.begin() as conn:
        conn.execute(text(sql))

# Helper function for SQL queries with output
def query_sql(sql: str):
    with engine.connect() as conn:
        result = conn.execute(text(sql))
        for row in result:
            print(row)
        print()



# PART 1 (DB setup)

def setup_database():

    exec_sql("""
        CREATE TABLE "user" (
            user_id SERIAL PRIMARY KEY,
            email VARCHAR(255) UNIQUE NOT NULL,
            given_name VARCHAR(100) NOT NULL,
            surname VARCHAR(100) NOT NULL,
            city VARCHAR(100),
            phone_number VARCHAR(20) NOT NULL,
            profile_description TEXT,
            password VARCHAR(255) NOT NULL
        );
    """)

    exec_sql("""
        CREATE TABLE caregiver (
            caregiver_user_id INTEGER PRIMARY KEY,
            photo TEXT,
            gender VARCHAR(20) NOT NULL,
            caregiving_type VARCHAR(50) NOT NULL,
            hourly_rate NUMERIC(6,2) NOT NULL,
            CONSTRAINT caregiver_foreignkey
                FOREIGN KEY (caregiver_user_id)
                    REFERENCES "user"(user_id)
                    ON DELETE CASCADE
        );
    """)

    exec_sql("""
        CREATE TABLE member (
            member_user_id INTEGER PRIMARY KEY,
            house_rules TEXT,
            dependent_description TEXT NOT NULL,
            CONSTRAINT member_foreignkey
                FOREIGN KEY (member_user_id)
                    REFERENCES "user"(user_id)
                    ON DELETE CASCADE
        );
    """)

    exec_sql("""
        CREATE TABLE address (
            member_user_id INTEGER PRIMARY KEY,
            house_number VARCHAR(20),
            street VARCHAR(255),
            town VARCHAR(100) NOT NULL,
            CONSTRAINT address_foreignkey
                FOREIGN KEY (member_user_id)
                    REFERENCES member(member_user_id)
                    ON DELETE CASCADE
        );
    """)

    exec_sql("""
        CREATE TABLE job (
            job_id SERIAL PRIMARY KEY,
            member_user_id INTEGER NOT NULL,
            required_caregiving_type VARCHAR(50) NOT NULL,
            other_requirements TEXT,
            date_posted DATE NOT NULL,
            CONSTRAINT job_foreignkey
                FOREIGN KEY (member_user_id)
                    REFERENCES member(member_user_id)
                    ON DELETE CASCADE
        );
    """)

    exec_sql("""
        CREATE TABLE job_application (
            caregiver_user_id INTEGER NOT NULL,
            job_id INTEGER NOT NULL,
            date_applied DATE NOT NULL,
            PRIMARY KEY (caregiver_user_id, job_id),
            CONSTRAINT application_caregiver_foreignkey
                FOREIGN KEY (caregiver_user_id)
                    REFERENCES caregiver(caregiver_user_id)
                    ON DELETE CASCADE,
            CONSTRAINT application_job_foreignkey
                FOREIGN KEY (job_id)
                    REFERENCES job(job_id)
                    ON DELETE CASCADE
        );
    """)

    exec_sql("""
        CREATE TABLE appointment (
            appointment_id SERIAL PRIMARY KEY,
            caregiver_user_id INTEGER NOT NULL,
            member_user_id INTEGER NOT NULL,
            appointment_date DATE NOT NULL,
            appointment_time TIME NOT NULL,
            work_hours NUMERIC(3,1) NOT NULL,
            status VARCHAR(20) NOT NULL,
            CONSTRAINT appointment_caregiver_foreignkey
                FOREIGN KEY (caregiver_user_id)
                    REFERENCES caregiver(caregiver_user_id)
                    ON DELETE CASCADE,
            CONSTRAINT appointment_member_foreignkey
                FOREIGN KEY (member_user_id)
                    REFERENCES member(member_user_id)
                    ON DELETE CASCADE
        );
    """)

    # Part 2 (Data insertion)

    # Users
    exec_sql("""
        INSERT INTO "user" (email, given_name, surname, city, phone_number, profile_description, password)
        VALUES
        ('arman@gmail.com',    'Arman',    'Armanov',     'Astana',   '+77771110001', 'Experienced caregiver', 'pass1'),
        ('dias@gmail.com',     'Dias',     'Serikov',     'Astana',   '+77771110002', 'Babysitter profile', 'pass2'),
        ('karina@gmail.com',   'Karina',   'Suleimenova', NULL,       '+77771110003', 'Patient and active', 'pass3'),
        ('aliya@gmail.com',    'Aliya',    'Tulegenova',  'Astana',   '+77771110004', 'Elderly care needed', 'pass4'),
        ('amina@gmail.com',    'Amina',    'Aminova',     'Astana',   '+77771110005', 'Mother seeking care', 'pass5'),
        ('marat@gmail.com',    'Marat',    'Kassymov',    'Astana',   '+77771110006', 'Father of special needs child', 'pass6'),
        ('dina@gmail.com',     'Dina',     'Mukasheva',   'Astana',   '+77771110007', 'Mother of 2 kids', 'pass7'),
        ('alua@gmail.com',     'Alua',     'Beketova',    NULL,       '+77771110008', 'Babysitter', 'pass8'),
        ('zhanel@gmail.com',   'Zhanel',   'Asylova',     'Astana',   '+77771110009', 'Part-time helper', 'pass9'),
        ('azamat@gmail.com',   'Azamat',   'Turysbek',    'Astana',   '+77771110010', 'Looking for care', 'pass10'),
        ('timur@gmail.com',    'Timur',    'Yesen',       'Astana',   '+77771110011', 'Elderly care needed', 'pass11'),
        ('botagoz@gmail.com',  'Botagoz',  'Rakhim',      NULL,       '+77771110012', 'Babysitter needed', 'pass12'),
        ('adel@gmail.com',     'Adel',     'Kenzhe',      NULL,       '+77771110013', 'Student caregiver', 'pass13'),
        ('saule@gmail.com',    'Saule',    'Akhmetova',   'Astana',   '+77771110014', 'Needs daytime help', 'pass14'),
        ('yerbol@gmail.com',   'Yerbol',   'Nurtay',      'Astana',   '+77771110015', 'Caregiver', 'pass15'),
        ('nazerke@gmail.com',  'Nazerke',  'Tatykh',      NULL,       '+77771110016', 'Parent needing help', 'pass16'),
        ('baur@gmail.com',     'Baur',     'Seit',        'Astana',   '+77771110017', 'Caregiver profile', 'pass17'),
        ('aikerim@gmail.com',  'Aikerim',  'Ospanova',    NULL,       '+77771110018', 'Mom of toddler', 'pass18'),
        ('samat@gmail.com',    'Samat',    'Kerimov',     'Astana',   '+77771110019', 'Not member/caregiver', 'pass19'),
        ('dana@gmail.com',     'Dana',     'Osken',       'Astana',   '+77771110020', 'Not member/caregiver', 'pass20');
    """)

    # Caregivers
    exec_sql("""
        INSERT INTO caregiver (caregiver_user_id, photo, gender, caregiving_type, hourly_rate)
        VALUES
        (1, NULL, 'Male',   'babysitter', 8.50),
        (2, NULL, 'Male',   'playmate',   9.00),
        (3, NULL, 'Female', 'elderly',    12.00),
        (6, NULL, 'Male',   'elderly',    11.00),
        (7, NULL, 'Female', 'babysitter', 7.50),
        (8, NULL, 'Female', 'babysitter', 6.50),
        (9, NULL, 'Female', 'playmate',   15.00),
        (10,NULL, 'Male',   'elderly',    9.50),
        (11,NULL, 'Male',   'elderly',    14.00),
        (12,NULL, 'Female', 'babysitter', 10.00);
    """)

    # Members
    exec_sql("""
        INSERT INTO member (member_user_id, house_rules, dependent_description)
        VALUES
        (13, 'No smoking.',          'Child age 4'),
        (14, 'Quiet home.',          'Elderly parent'),
        (15, 'No pets.',             'Disabled adult'),
        (16, 'Friendly dog present','Child age 2'),
        (17, 'No alcohol.',          'Grandmother'),
        (18, 'Clean environment.',   'Baby 1 year'),
        (19, 'No shoes indoors.',    'Child age 6'),
        (20, 'Quiet household.',     'Elderly father'),
        (4,  'No pets.',             'Elderly mother'),
        (5,  'No loud noises.',      'Child with ASD');
    """)

    # Address
    exec_sql("""
        INSERT INTO address (member_user_id, house_number, street, town)
        VALUES
        (13, '12', 'Kabanbay Batyr', 'Astana'),
        (14, '77', 'Kabanbay Batyr', 'Astana'),
        (15, '103','Kabanbay Batyr', 'Astana'),
        (16, '22', 'Turan',          'Astana'),
        (17, '5',  'Saryarka',       'Astana'),
        (18, '10', 'Bokeikhan',      'Astana'),
        (19, '44', 'Uly Dala',       'Astana'),
        (20, '17', 'Mangilik El',    'Astana'),
        (4,  '8',  'Abay',           'Astana'),
        (5,  '3',  'Pushkin',        'Astana');
    """)

    # Job
    exec_sql("""
        INSERT INTO job (member_user_id, required_caregiving_type, other_requirements, date_posted)
        VALUES
        (13, 'babysitter', 'soft-spoken and calm', '2025-01-05'),
        (14, 'elderly',    'gentle and patient',  '2025-01-06'),
        (15, 'playmate',   NULL,                  '2025-01-07'),
        (16, 'babysitter', 'energetic person',    '2025-01-08'),
        (17, 'elderly',    'experienced',         '2025-01-09'),
        (18, 'babysitter', NULL,                  '2025-01-10'),
        (19, 'elderly',    'soft-spoken preferred','2025-01-11'),
        (20, 'playmate',   NULL,                  '2025-01-12'),
        (4,  'elderly', 'No pets. Must be kind.', '2025-01-13'),
        (5,  'elderly', 'No pets. Soft-spoken.',  '2025-01-14'),
        (13, 'babysitter', NULL, '2025-01-15'),
        (14, 'playmate', 'fun attitude', '2025-01-16'),
        (15, 'elderly', 'patient', '2025-01-17'),
        (16, 'babysitter', 'soft-spoken preferred', '2025-01-18'),
        (17, 'elderly', 'strong person needed', '2025-01-19');
    """)

    # Job_application
    exec_sql("""
        INSERT INTO job_application (caregiver_user_id, job_id, date_applied)
        VALUES
        (1, 1, '2025-01-20'),
        (2, 1, '2025-01-20'),
        (3, 2, '2025-01-21'),
        (6, 2, '2025-01-21'),
        (7, 3, '2025-01-22'),
        (8, 4, '2025-01-22'),
        (9, 5, '2025-01-22'),
        (10,6, '2025-01-23'),
        (11,7, '2025-01-23'),
        (12,8, '2025-01-23'),
        (1, 9, '2025-01-24'),
        (2, 10,'2025-01-24'),
        (3, 11,'2025-01-25'),
        (6, 12,'2025-01-25'),
        (7, 13,'2025-01-25');
    """)

    # Appointment
    exec_sql("""
        INSERT INTO appointment (caregiver_user_id, member_user_id, appointment_date, appointment_time, work_hours, status)
        VALUES
        (1, 13, '2025-01-10', '09:00', 2.0, 'accepted'),
        (2, 14, '2025-01-10', '10:00', 3.5, 'accepted'),
        (3, 15, '2025-01-11', '14:00', 1.5, 'accepted'),
        (6, 16, '2025-01-11', '15:00', 4.0, 'accepted'),
        (7, 17, '2025-01-12', '09:30', 2.5, 'accepted'),
        (8, 18, '2025-01-12', '10:30', 3.0, 'pending'),
        (9, 19, '2025-01-12', '11:00', 1.0, 'pending'),
        (10,20,'2025-01-12','12:00', 2.0, 'pending'),
        (11,13,'2025-01-13','13:00', 1.0, 'completed'),
        (12,14,'2025-01-13','13:30', 3.5, 'completed'),
        (1, 15,'2025-01-13','14:00', 2.0, 'completed'),
        (2, 16,'2025-01-14','08:00', 1.5, 'cancelled'),
        (3, 17,'2025-01-14','09:00', 2.0, 'cancelled'),
        (6, 18,'2025-01-14','10:00', 10.5, 'accepted'),
        (7, 19,'2025-01-15','11:00', 9.0,  'accepted');
    """)



# PART 2 (Queries)


def update_queries():
    # 3.1 Update the phone number of Arman Armanov to +77773414141
    exec_sql("""
        UPDATE "user"
        SET phone_number = '+77773414141'
        WHERE given_name = 'Arman' AND surname = 'Armanov';
    """)

    # 3.2 Add $0.3 commission fee to the Caregivers’ hourly rate if it's less than $10, or 10% if it's not
    exec_sql("""
        UPDATE caregiver
        SET hourly_rate = hourly_rate + 0.3
        WHERE hourly_rate < 10;
    """)

    exec_sql("""
        UPDATE caregiver
        SET hourly_rate = hourly_rate * 1.10
        WHERE hourly_rate >= 10;
    """)


def delete_queries():
    # 4.1 Delete the jobs posted by Amina Aminova.
    exec_sql("""
        DELETE FROM job
        WHERE member_user_id = (
            SELECT user_id FROM "user"
            WHERE given_name='Amina' AND surname='Aminova'
        );
    """)

    # 4.2 Delete all members who live on Kabanbay Batyr street. 
    exec_sql("""
        DELETE FROM member
        WHERE member_user_id IN (
            SELECT member_user_id
            FROM address
            WHERE street='Kabanbay Batyr'
        );
    """)


def simple_queries():
    # 5.1 Select caregiver and member names for the accepted appointments.
    exec_sql("""
        SELECT 
            u_c.given_name AS caregiver_name,
            u_m.given_name AS member_name
        FROM appointment a
        JOIN "user" u_c ON a.caregiver_user_id = u_c.user_id
        JOIN "user" u_m ON a.member_user_id = u_m.user_id
        WHERE a.status = 'accepted';
    """)

    # 5.2 List job ids that contain ‘soft-spoken’ in their other requirements
    query_sql("""
        SELECT *
        FROM job
        WHERE other_requirements ILIKE '%soft-spoken%';
    """)

    # 5.3 List the work hours of all babysitter positions
    query_sql("""
        SELECT a.work_hours
        FROM appointment a
        JOIN job j ON a.member_user_id = j.member_user_id
        WHERE j.required_caregiving_type = 'babysitter';
    """)

    # 5.4 List the members who are looking for Elderly Care in Astana and have “No pets.” rule.
    query_sql("""
        SELECT j.*
        FROM job j
        JOIN member m ON j.member_user_id = m.member_user_id
        JOIN "user" u ON m.member_user_id = u.user_id
        WHERE j.required_caregiving_type='elderly'
          AND j.other_requirements ILIKE '%No pets%'
          AND u.city='Astana';
    """)


def complex_queries():
    # 6.1 Count the number of applicants for each job posted by a member (multiple joins with aggregation)
    query_sql("""
        SELECT 
            j.job_id,
            m.member_user_id,
            COUNT(ja.caregiver_user_id) AS applicant_count
        FROM job j
        JOIN member m 
            ON j.member_user_id = m.member_user_id
        LEFT JOIN job_application ja 
            ON j.job_id = ja.job_id
        GROUP BY j.job_id, m.member_user_id
        ORDER BY j.job_id;
    """)

    # 6.2 Total hours spent by care givers for all accepted appointments (multiple joins with aggregation)
    query_sql("""
        SELECT 
            c.caregiver_user_id,
            u.given_name,
            SUM(a.work_hours) AS total_hours
        FROM appointment a
        JOIN caregiver c 
            ON a.caregiver_user_id = c.caregiver_user_id
        JOIN "user" u 
            ON c.caregiver_user_id = u.user_id
        WHERE a.status = 'accepted'
        GROUP BY c.caregiver_user_id, u.given_name
        ORDER BY c.caregiver_user_id;
    """)

    # 6.3 Average pay of caregivers based on accepted appointments (join with aggregation)
    query_sql("""
        SELECT 
            c.caregiver_user_id,
            u.given_name,
            AVG(c.hourly_rate * a.work_hours) AS avg_pay
        FROM appointment a
        JOIN caregiver c 
            ON a.caregiver_user_id = c.caregiver_user_id
        JOIN "user" u 
            ON c.caregiver_user_id = u.user_id
        WHERE a.status = 'accepted'
        GROUP BY c.caregiver_user_id, u.given_name
        ORDER BY c.caregiver_user_id;
    """)

    # 6.4 Caregivers who earn above average based on accepted appointments (multiple join with aggregation and nested query)
    query_sql("""
        SELECT 
            c.caregiver_user_id,
            u.given_name,
            SUM(a.work_hours * c.hourly_rate) AS total_earnings
        FROM appointment a
        JOIN caregiver c 
            ON a.caregiver_user_id = c.caregiver_user_id
        JOIN "user" u 
            ON c.caregiver_user_id = u.user_id
        WHERE a.status = 'accepted'
        GROUP BY c.caregiver_user_id, u.given_name
        HAVING SUM(a.work_hours * c.hourly_rate) >
            (
                SELECT AVG(a2.work_hours * c2.hourly_rate)
                FROM appointment a2
                JOIN caregiver c2 
                    ON a2.caregiver_user_id = c2.caregiver_user_id
                WHERE a2.status = 'accepted'
            )
        ORDER BY total_earnings DESC;
    """)

def derived_queries():
    # 7 Calculate the total cost to pay for a caregiver for all accepted appointments
    query_sql("""
        SELECT 
            c.caregiver_user_id,
            u.given_name,
            SUM(a.work_hours * c.hourly_rate) AS total_cost
        FROM appointment a
        JOIN caregiver c 
            ON a.caregiver_user_id = c.caregiver_user_id
        JOIN "user" u 
            ON c.caregiver_user_id = u.user_id
        WHERE a.status = 'accepted'
        GROUP BY c.caregiver_user_id, u.given_name
        ORDER BY total_cost DESC;
    """)

def view_queries():
    # 8 View all job applications and the applicants
    exec_sql("""
        CREATE VIEW job_applicants_view AS
        SELECT 
            ja.job_id,
            ja.date_applied,
            u.given_name AS caregiver_name,
            u.surname AS caregiver_surname
        FROM job_application ja
        JOIN caregiver c 
            ON ja.caregiver_user_id = c.caregiver_user_id
        JOIN "user" u 
            ON c.caregiver_user_id = u.user_id;
    """)

    query_sql("""
        SELECT * FROM job_applicants_view;
    """)

    exec_sql("""
        DROP VIEW IF EXISTS job_applicants_view;
    """)



#setup_database()
update_queries()
delete_queries()
simple_queries()
complex_queries()
derived_queries()
view_queries()